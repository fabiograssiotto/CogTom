Zahid - a computational implementation of the Theory of Mind model.  
The intent of this software program is to evaluate false belief tasks.

Directory structure:  
\input - environment inputs  
\memory - simulation for Belief Memory  
\model - Thoery of Mind model modules  
\output - utility classes and output reports  
